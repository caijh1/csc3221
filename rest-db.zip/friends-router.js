var express = require('express');       // imports the express library
var router = express.Router();          // Router object for routes

var friendModel = require('./models/friends');
var db = require('./db');

// test route to make sure everything is working
// (accessed at GET http://leia.cs.spu.edu:3000/api)
router.get('/', function HomeGetHandler(request, response) {
    
    db.connect(function ConnectionHandler(err){
        if (err){
            console.log('Unable to connect to MySQL');
            process.exit(1);
        }else{
            console.log("Successfully connected");
        response.json({ message: 'It Works' });
        }
    });
});



router.get('/friends', function FriendsGetHandler(request, response){
    friendModel.getAll(function DoneGettingAll(err, result, fields){
        if (err) {
            console.log("Some error selecting all");
            console.log(err);
            response.write("Error Getting All");
        } else {
            console.log("Successfully retrieve all records (100)");
            response.json(result);
        }
    });
});



router.post('/friends', function FriendsPostHandler(request, response){
    friendModel.insert( request.body.birthDate,
                        request.body.firstName,
                        request.body.lastName,
                        request.body.gender,
                        request.body.phone, function DoneInserting(err, resultId){
                            if (err){
                                console.log("Some error inserting");
                                console.log(err);
                                response.write("Error Inserting");
                            }else{
                                console.log("Successfully inserted");
                                response.json({ insertedId: resultId });
                            }
                        } );
});



router.put('/:friend_id', function FriendsPutHandler(request, response){
    friendModel.update( parseInt(request.params.friend_id),
        request.body.birthDate,
        request.body.firstName,
        request.body.lastName,
        request.body.gender,
        request.body.phone, function DoneUpdating(err, affectedRows){
            if (err){
                console.log("Some error updating");
                console.log(err);
                response.write("Error Updating");
            }else{
                console.log("Successfully inserted");
                response.json({ updateId: affectedRows });
            }
        } );
});


router.delete('/:friend_id', function FriendsDeleteHandler(request, response){
    console.log("2");
    friendModel.delete( parseInt(request.params.friend_id), function DoneDelete(err, affectedRows){
                            if (err){
                                console.log("Some error delete");
                                console.log(err);
                                response.write("Error Delete");
                            }else{
                                console.log("Successfully inserted");
                                response.json({ deleteId: affectedRows });
                            }
                        } );
});


module.exports = router;