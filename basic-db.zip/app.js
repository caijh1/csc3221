
/**
 * Module dependencies.
 */

var express = require('express');
var app = express();
var path    = require("path");

var myRouter = require('./employees.router');



//Serves static content from directory public
app.use('/', express.static('public'));

app.use('/', myRouter);





app.listen(3006, function ServerListener() {
    console.log('Sample App with router. This app serves static content');
});
