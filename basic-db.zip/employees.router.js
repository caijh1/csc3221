var express = require('express');	// imports the express library
var router = express.Router();		// Router object for routes

var db = require('./db.js');

    db.connect(function ConnectionHandler(err){
        if (err){
            console.log('Unable to connect to MySQL');
            process.exit(1);
        }
     });

// Setting the more-info response
router.get('/employees', function (request, response) {
         //Just to test... this should not be here.
        db.get().query('SELECT * FROM employees LIMIT 30', function QueryHandler(err, result, fields){
            if (err) throw err;
            console.log("Successfully retrieve all records (100)");
            response.json(result);
        });
});

router.get('/salaries', function (request, response) {
        db.get().query('SELECT emp_no, salary FROM salaries LIMIT 30', function QueryHandler(err, result, fields){
            if (err) throw err;
            response.json(result);
        });
});

router.get('/current_dept_emp', function (request, response) {
        db.get().query('SELECT emp_no, dept_no FROM current_dept_emp LIMIT 30', function QueryHandler(err, result, fields){
            if (err) throw err;
            response.json(result);
        });
});

router.get('/departments', function (request, response) {
        db.get().query('SELECT dept_no, dept_name FROM departments LIMIT 30', function QueryHandler(err, result, fields){
            if (err) throw err;
            response.json(result);
        });
});

router.get('/dept_manager', function (request, response) {
        db.get().query('SELECT dept_no, emp_no FROM dept_manager LIMIT 30', function QueryHandler(err, result, fields){
            if (err) throw err;
            response.json(result);
        });
});

// Exporting the router "object"
module.exports = router;